% O-CAT data 240107 _ SoRin
clear all; clc; close all;
cd ('Z:\E-Phys Analysis\fMRI_ocat\OCAT_BHV\code\Learning Analysis');

%% set path 
path_in= '../../data/data_learning_curve/Responses';
path_out='../../data/data_learning_curve/Expectation Maximization';
sbj_info_path = '../../data/data_bhv_log_table/total/sbj_info.xlsx';
addpath(genpath(path_out));

%% Input
n_sbj = 31;
cdata_table = table('Size',[n_sbj 2], 'VariableTypes',["string" "double"],'VariableNames',["Session","acq_onset"]);
init_cond = 1; %set the initial condition, default : 2
%                  0-to fix initial condition (more likely to give a result)
%                  1-to estimate initial condition 
%                  2-to remove xo from likelihood - this means that the latent
% 				     learning process is not started at 0 and allows for alot of bias 

if init_cond == 2; disp('initial condition -- default; allows bias');
elseif init_cond == 0; disp('initial condition -- fixed; more likely to give a result');
elseif init_cond == 1; disp('initial condition -- estimate'); end

path_out = fullfile(path_out, ['init_cond_' num2str(init_cond)]);
mkdir(path_out);

%% sbj_info_file
sbj_info_table = readtable(sbj_info_path);

%% subject numbering , folder root
for sbj_i = 1: n_sbj
    c_sbj = strcat('sub-', num2str(sbj_i, '%02.f'));

% Responses -> 0 : incorrect trial + timeout, 1: correct trial
load(fullfile(path_in, [c_sbj '_Responses.mat']));

cdata = LearningCurve_EM(Responses,init_cond);
cdata_table.Session(sbj_i) = c_sbj;cdata_table.acq_onset(sbj_i) = cdata;

plot_learning_curve_SR;

disp(['Completed processing for subject: ', c_sbj]);
disp(['acq_onset: ', string(cdata)]);
end

fieldname = sprintf('EM_acq_onset_%d', init_cond);
sbj_info_table.(fieldname) = cdata_table.acq_onset;
writetable(sbj_info_table,sbj_info_path);

% acquisition_onset을 double .mat file로 저장
EM_acq_onset_double = double(cdata_table.acq_onset);
save([path_out '\EM_acq_onset.mat'], 'EM_acq_onset_double');

save(fullfile(path_out, [fieldname '.mat']),'EM_acq_onset_double');

fprintf('Unlearned n_sbj = %d\n', length(find(isnan(EM_acq_onset_double))));

