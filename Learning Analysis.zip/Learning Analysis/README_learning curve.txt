how to get learning curve
[Estimating two simulated learning curves: EM  algorithm  and  the  Gibbs  sampling  algorithm]

1. Select Algorithm: Gibbs' Sampling(WinBugs) VS Expectation Maximization(EM)

* Gibbs' Sampling 
: a probabilistic framework which assumes all parameters to be learned are random 
variables.this algorithm is stochastic so that it may arrive at different solutions 
from the same initial parameters.

-> In general, it is best to use the Gibbs Sampling method (computationally efficient 
and small MISE), except in the case of long datasets.


* Expectation Maximization
: a deterministic framework that, when started with the same initial parameters, 
will always converge to the same solution. Therefore, it is wise to start it multiple 
times from different initial parameters.

Assuming a Gaussian mixture model to maximize the likelihood of the observed data.
-> Use the Expectation Maximization software for long (> 100 trials) datasets

In short, 
EM is purely an optimization procedure while Gibbs sampling is a Bayesian approach.




