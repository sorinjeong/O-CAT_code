% Data example
block1 = [0	0	1	1	0	1	0	1	0	1	1	1	1	1	0	1	1	1	1	1	1]; % 0 : incorrect trial, 1: correct trial
[pdata1 cdata1] = LearningCurve_WinBugs(block1);
block2 = [0	0	0	1	0	0	1	1	0	1	0	1	1	1	1	0	0	1	1	1	1	1	0	1	1	1	1]; % 0 : incorrect trial, 1: correct trial
[pdata2 cdata2] = LearningCurve_WinBugs(block2);
block3 = [0	0	0	0	0	0	1	0	0	0	1	0	1	1	0	0	0	1	0	1	1	1	0	1	0	1	1	1	1	1	1	1	1	1]; % 0 : incorrect trial, 1: correct trial
[pdata3 cdata3] = LearningCurve_WinBugs(block3);

% Plot example
figure(1)
subplot(3,1,1)
plotI(block1, ones(1,length(block1))); hold on;
xlabel('Trial Number');
ylabel('Pr(Correct Response)')
plot(pdata1(:,2),'k-'); hold on;
plot(pdata1(:,3),'r-'); hold on;
plot(pdata1(:,4),'k-');
l=line([cdata1 cdata1],[0 1]); l.Color='b'; l.LineWidth=1;
title('block 1')
g=gca; 
g.FontSize=12;

subplot(3,1,2)
plotI(block2, ones(1,length(block2))); hold on;
xlabel('Trial Number');
ylabel('Pr(Correct Response)')
plot(pdata2(:,2),'k-'); hold on;
plot(pdata2(:,3),'r-'); hold on;
plot(pdata2(:,4),'k-');
l=line([cdata2 cdata2],[0 1]); l.Color='b'; l.LineWidth=1;
title('block 2')
g=gca; 
g.FontSize=12;

subplot(3,1,3)
plotI(block3, ones(1,length(block3))); hold on;
xlabel('Trial Number');
ylabel('Pr(Correct Response)')
plot(pdata3(:,2),'k-'); hold on;
plot(pdata3(:,3),'r-'); hold on;
plot(pdata3(:,4),'k-');
l=line([cdata3 cdata3],[0 1]); l.Color='b'; l.LineWidth=1;
title('block 3')
g=gca; 
g.FontSize=12;

save('E:\sample.mat', 'block1', 'block2', 'block3', 'pdata1', 'pdata2', 'pdata3', 'cdata1', 'cdata2', 'cdata3')