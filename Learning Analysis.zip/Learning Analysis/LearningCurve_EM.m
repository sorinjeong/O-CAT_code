function cdata = LearningCurve_EM(Responses,init_cond,Chance)
%Learning Analysis using EM algorithm 
%Smith et al., 2004
%run this script within Matlab
%Modified by Jeong So Rin 240107

%% Input data
% Responses : behavior data, binary format
% BackgroundProb : chance level, default : 0.5
% SigE : SIG_EPSILON, default 0.005 -- (optional) sqrt(variance) of learning state process
% UpdaterFlag : set the initial condition, default : 2
%               0-to fix initial condition (more likely to give a result)
%               1-to estimate initial condition 
%               2-to remove xo from likelihood - this means that the latent
% 				learning process is not started at 0 and allows for alot of bias 

%% Output data
% cdata : learning trial

%% Set Path
path_code= 'Z:\E-Phys Analysis\fMRI_ocat\OCAT_BHV\code\Learning Analysis';
addpath(genpath([path_code '\Learning Analysis\IndividualAnalysisEM']));

%% Set variables

if ~exist('Responses','var'),  error('Responses is missing!'); end
if nargin == 2; BackgroundProb=0.5;elseif nargin == 3; BackgroundProb = Chance; end % Chance level

SigE = 0.005; %default variance of learning state process is sqrt(0.005)
UpdaterFlag=init_cond; %initial condition
MaxResponse=1*ones(1,length(Responses));
        
%% check data format.  Reshape dataset if needed
[a,b] = size(Responses);
if a>b
    Responses = Responses';
end

I = [Responses; MaxResponse];

SigsqGuess  = SigE^2;

%set the value of mu from the chance of correct
 mu = log(BackgroundProb/(1-BackgroundProb)); 

%convergence criterion for SIG_EPSILON^2
 CvgceCrit = 1e-8;

%----------------------------------------------------------------------------------

xguess         = 0;  
NumberSteps  = 2000;

%loop through EM algorithm: forward filter, backward filter, then
%M-step
for i=1:NumberSteps
   
   %Compute the forward (filter algorithm) estimates of the learning state
   %and its variance: x{k|k} and sigsq{k|k}
   [p, x, s, xold, sold] = forwardfilter(I, SigE, xguess, SigsqGuess, mu);   
   
   %Compute the backward (smoothing algorithm) estimates of the learning 
   %state and its variance: x{k|K} and sigsq{k|K}
   [xnew, signewsq, A]   = backwardfilter(x, xold, s, sold); 

   if (UpdaterFlag == 1)
        xnew(1) = 0.5*xnew(2);   %updates the initial value of the latent process
        signewsq(1) = SigE^2;
   elseif(UpdaterFlag == 0)
        xnew(1) = 0;             %fixes initial value (no bias at all)
        signewsq(1) = SigE^2;
   elseif(UpdaterFlag == 2)
        xnew(1) = xnew(2);       %x(0) = x(1) means no prior chance probability
        signewsq(1) = signewsq(2);
   end
   
   %Compute the EM estimate of the learning state process variance
   [newsigsq(i)]         = em_bino(I, xnew, signewsq, A, UpdaterFlag);
   
   xnew1save(i) = xnew(1);
   
   %check for convergence
   if(i>1)
      a1 = abs(newsigsq(i) - newsigsq(i-1));
	  a2 = abs(xnew1save(i) -xnew1save(i-1));
      if( a1 < CvgceCrit & a2 < CvgceCrit & UpdaterFlag >= 1)
          fprintf(2, 'EM estimates of learning state process variance and start point converged after %d steps   \n',  i)
          break
      elseif ( a1 < CvgceCrit & UpdaterFlag == 0)
          fprintf(2, 'EM estimate of learning state process variance converged after %d steps   \n',  i)
          break
      end
   end
 
   SigE   = sqrt(newsigsq(i));
   xguess = xnew(1);
   SigsqGuess = signewsq(1);

end
   
if(i == NumberSteps)
     fprintf(2,'failed to converge after %d steps; convergence criterion was %f \n', i, CvgceCrit)
end

%-----------------------------------------------------------------------------------
%integrate and do change of variables to get confidence limits

[p05, p95, pmid, pmode, pmatrix] = pdistn(xnew, signewsq, mu, BackgroundProb);

%-------------------------------------------------------------------------------------
%find the last point where the 90 interval crosses chance
%for the backward filter (cdata)

cdata = find(p05 < BackgroundProb);

if(~isempty(cdata))
  if(cdata(end) < size(I,2) )
       cdata = cdata(end);
  else
       cdata = NaN;
  end
else
  cdata = NaN;
end

save('resultsindividual');

% plot_learning_curve_SR;
% trialtotrial;

