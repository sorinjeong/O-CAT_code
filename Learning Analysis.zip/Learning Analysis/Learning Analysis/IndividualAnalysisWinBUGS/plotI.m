function [h1, h2] = plotI(Responses, MaxResponses)

%plots binary data
t = 1:length(Responses);
if(length(MaxResponses) == sum(MaxResponses == 1))
  hold on; [y, x] = find(Responses > 0);
  h1 = plot(x,y+0.05,'s'); set(h1, 'MarkerFaceColor','k');
  set(h1, 'MarkerEdgeColor', 'k');
  hold on; [y, x] = find(Responses == 0);
  h2 = plot(x,y+0.05,'s'); set(h2, 'MarkerFaceColor', [0.75 0.75 0.75]);
  set(h2, 'MarkerEdgeColor', 'k');
end
axis([1 t(end)  0 1.10]); box on;
  
  