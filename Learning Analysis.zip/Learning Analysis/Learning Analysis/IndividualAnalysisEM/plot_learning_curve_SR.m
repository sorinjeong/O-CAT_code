%-------------------------------------------------------------------------------------
%plot the figures
load('resultsindividual');

 t=1:size(p,2)-1; 

 f=figure('Position', [830,791,1456,554]);  clf;

%% plot learning curve
subplot(121)
xlabel('Trial Number')
ylabel('Probability of a Correct Response')

plot(t, pmode(2:end),'r-','LineWidth',1.2); hold on;
%plot(t, p05(2:end),'k', t, p95(2:end), 'k');
plot(t, p05(2:end),'k-','LineWidth',1.2); hold on;
plot(t, p95(2:end),'k-','LineWidth',1.2); hold on;

if(MaxResponse == 1)
    hold on; [y, x] = find(Responses > 0);
    h = plot(x,y+0.05,'s'); set(h, 'MarkerFaceColor','k');
    set(h, 'MarkerEdgeColor', 'k');
    hold on; [y, x] = find(Responses == 0);
    h = plot(x,y+0.05,'s'); set(h, 'MarkerFaceColor', [0.75 0.75 0.75]);
    set(h, 'MarkerEdgeColor', 'k');
    axis([1 t(end)  0 1.05]);
else
    hold on; plot(t, Responses./MaxResponse,'ko');
    axis([1 t(end)  0 1]);
end

ly=line([1 t(end)], [BackgroundProb  BackgroundProb ]);
set(ly, 'LineStyle', '--', 'LineWidth', 1);hold on;
l=line([cdata cdata],[0 1]); l.Color='b'; l.LineWidth=1.8;

% Fill the area between plot(p05) and plot(p95) with a transparent gray color with 60% opacity
fillx = 0:length(p05)-1;
fill([fillx fliplr(fillx)], [p05 fliplr(p95)], [0.5 0.5 0.5], 'FaceAlpha', 0.6, 'EdgeColor', 'none');

title(['LearningCurve: ' c_sbj],'FontSize',20,'FontWeight','bold');
subtitle(sprintf('%s%d\n%s%.2f', 'IO(0.95) Learning trial = ',cdata,'Learning state process variance = ', SigE^2));

% Remove the top and right axes lines
box off;



%% plot IO certainty
 subplot(122)
 plot(t,1 - pmatrix(2:end),'k');hold on;
 line([ 1 t(end)],[0.90 0.90]);
 line([ 1 t(end)],[0.99 0.99]);
 line([ 1 t(end)],[0.95 0.95]);
 axis([1 t(end)  0 1]);
 grid on;
 title('IO certainty','FontSize',14,'FontWeight','bold');
 subtitle('* IO : Interval of Uncertainty')
 xlabel('Trial Number')
 ylabel('Certainty')
 
 %save
saveas(f,[path_out '\' c_sbj '_learning_curve'],'png');

 hold off; close