% O-CAT data 231218
% clear all; clc; close all;
cd ('Z:\E-Phys Analysis\fMRI_ocat\OCAT_BHV\code\Learning Analysis');

%% set path 
path_in= '../../data/0902/total/data_learning_curve/Responses';
path_out='../../data/0902/total/data_learning_curve/curve_95';
sbj_info_path = '../../data/0902/total/data_bhv_log_table/total/sbj_info.xlsx';
mkdir(path_out);

%% Input
n_sbj = 40;
cdata_table = table('Size',[n_sbj 2], 'VariableTypes',["string" "double"],'VariableNames',["Session","acquisition_onset"]);
conf_interval = 0.95; % Set the confidence level (for 95%, type 0.95) 90/95/99
fprintf('conf_interval: %.0f%%\n', conf_interval*100);

% path_out = fullfile(path_out, sprintf('conf_interval_%.0f', conf_interval*100));
% mkdir(path_out);
%% sbj_info_file
sbj_info_table = readtable(sbj_info_path);

%% subject numbering , folder root
for sbj_i = 1: n_sbj
    c_sbj = strcat('sub-', num2str(sbj_i, '%02.f'));

% Responses -> 0 : incorrect trial + timeout, 1: correct trial
load(fullfile(path_in, [c_sbj '_Responses.mat']));

[pdata, cdata] = LearningCurve_WinBugs(Responses,conf_interval);
cdata_table.Session(sbj_i) = c_sbj; cdata_table.acquisition_onset(sbj_i) = cdata;
pdata_table.(sprintf('sub_%.2d',sbj_i)) = pdata(:,3);

%% Plot
f=figure('Position', [1500 200 800 600]);
plotI(Responses, ones(1,length(Responses))); hold on;
xlabel('Trial Number');
ylabel('Pr(Correct Response)')
plot(pdata(:,2),'k-','LineWidth',1.2); hold on;
plot(pdata(:,3),'r-','LineWidth',1.2); hold on;
plot(pdata(:,4),'k-','LineWidth',1.2); hold on;
ly=line([0 32], [0.5 0.5]);set(ly, 'LineStyle', '--', 'LineWidth', 1);hold on;
l=line([cdata cdata],[0 1]); l.Color='b'; l.LineWidth=1.8;

% Fill the area between plot(pdata(:,2)) and plot(pdata(:,3)) with a transparent gray color with 60% opacity
x = 1:length(pdata(:,2));
fill([x fliplr(x)], [pdata(:,2)' fliplr(pdata(:,4)')], [0.5 0.5 0.5], 'FaceAlpha', 0.6, 'EdgeColor', 'none');
title(['LearningCurve: ' c_sbj],'FontSize',14,'FontWeight','bold');
box off;

saveas(f,[path_out '\' c_sbj '_learning_curve'],'png');
hold off; close

disp(['Completed processing for subject: ', c_sbj]);
disp(['acquisition_onset: ', string(cdata)]);
end

fieldname = sprintf('acquisition_onset_%.0f', conf_interval*100);
sbj_info_table.(fieldname) = cdata_table.acquisition_onset;
writetable(sbj_info_table,sbj_info_path);

acquisition_onset_double = double(cdata_table.acquisition_onset);
save([path_out '\acquisition_onset.mat'], 'acquisition_onset_double');

save(fullfile(path_out, [fieldname '.mat']),'acquisition_onset_double');
save([path_out '\pdata_table.mat'],"pdata_table")
ptable=pdata_table;

% save('C:\Users\User\Desktop\JSR\pdata_re',"ptable")
save('Z:\E-Phys Analysis\fMRI_ocat\OCAT_BHV\code\Learning Analysis\pdata_re',"ptable")





